<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package romel-fowler-v2
 */

?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="<?php bloginfo('template_directory');?>/js/imagesloaded.pkgd.min.js"></script>
<script src="<?php bloginfo('template_directory');?>/js/anime.min.js"></script>
<script src="<?php bloginfo('template_directory');?>/js/mirrorFx.js"></script>
<script src="<?php bloginfo('template_directory');?>/js/slideshow.js"></script>
<script src="<?php bloginfo('template_directory');?>/js/main.js"></script>

<script>
(function() {

	function init() {
		new Slideshow(document.querySelector('.slideshow'));
	}

	// Fake loading time..
	var startTime = new Date().getTime();
	imagesLoaded(document.querySelector('main'), function() {
		var elapsed = new Date().getTime() - startTime,
			initFn = function() {
				document.body.classList.remove('loading');
				setTimeout(init, 50);
			};

		if( elapsed > 2000) {
			initFn();
		}
		else {
			setTimeout(initFn, 1000);
		}
	});

})();
</script>
<?php wp_footer(); ?>

</body>
</html>
