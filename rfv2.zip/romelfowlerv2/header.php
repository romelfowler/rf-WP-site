<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package romel-fowler-v2
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Rommel Fowler</title>
	<meta name="description" content="Rommel Fowler website is a portfolio that showcases all the design and
	development jobs Rommel Fowler has worked on in his years as a developer and application designer." />
	<meta name="keywords" content="template, page layout, concept, developer, designer, portfolio, effect, animation, css, javascript" />
	<meta name="author" content="Rommel-Fowler" />
	<link rel="shortcut icon" href="img/logo.png">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Arapey|Montserrat:700" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory');?>/css/normalize.css" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory');?>/css/style.css" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory');?>/css/mirror.css" />
	<script>document.documentElement.className = 'js';</script>

	<?php wp_head(); ?>
</head>

<body <?php body_class("rf-main loading"); ?>>
	<header>
		<a href="index.html"><img src="<?php bloginfo('stylesheet_directory');?>/img/logo@2x.png" alt="" class="logo"></a>
		<nav></nav>
	</header>
