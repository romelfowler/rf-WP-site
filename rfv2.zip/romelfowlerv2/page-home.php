<?php
/**
* Template Name: Home
 */

get_header();
?>

<main>
	<div class="cta">
		<h5 class="text color-text-flow">Hold On To Your Breeches - Full Features Coming Soon!</h5>
	</div>
	<section class="content content--full">


		<div class="slideshow">

			<div class="slide">
				<h2 class="page-title">Designer / Developer</h2>

				<div class="mirror" data-visible-area=".9" data-tilt>
					<div class="mirror__side mirror__side--one">
						<img class="mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="crow" />
					</div>
					<div class="mirror__side mirror__side--two">
						<img class="mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="crow" />
					</div>
				</div>
				<h2 class="slide__title "><span class="text color-text-flow">Rommel Fowler</span></h2>
			</div>

			<div class="slide">

				<div class="mirror">
					<div class="mirror__side mirror__side--one">
						<img class="display-none mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="Some image" />
					</div>
					<div class="mirror__side mirror__side--two">
						<img class="display-none mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="Some image" />
					</div>
				</div>
				<div class="overflow">
					<h1 class="text color-text-flow">Portfolio</h1>

					<section>
									<div id="card-1" class="card rounded">
											<!-- <div class="card__overlay"></div> -->
											<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/Bear.jpg" alt="Bear photo" /></a></div>
											<div class="card__heading">
													<span class="small">Manipulation</span>
													<h2>Bear Falls</h2>
											</div>
									</div>
									<div id="card-2" class="card rounded">
											<!-- <div class="card__overlay"></div> -->
											<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/elephant-12.jpg" alt="elephant photo" /></a></div>

											<div class="card__heading">
													<span class="small">Manipulation</span>
													<h2>Elephant <br/>Mountains</h2>
											</div>
									</div>
									<div id="card-3" class="card rounded">
										<!-- <div class="card__overlay"></div> -->
										<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/deer.jpg" alt="deer photo" /></a></div>

										<div class="card__heading">
												<span class="fc-black small">Manipulation</span>
												<h2 class="fc-black">Deer's Head</h2>
										</div>
									</div>
									<div id="card-4" class="card rounded">
										<!-- <div class="card__overlay"></div> -->
										<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/lion.jpg" alt="lion photo" /></a></div>

										<div class="card__heading">
												<span class="small">Manipulation</span>
												<h2>Lion</h2>
										</div>
									</div>

							</section>
							<section>
											<div id="card-1" class="card rounded">
												<!-- <div class="card__overlay"></div> -->
												<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/zepplin-12.jpg" alt="zepplin photo" /></a></div>

												<div class="card__heading">
														<span class="small">Manipulation</span>
														<h2>Zepplin</h2>
												</div>
											</div>
											<div id="card-2" class="card rounded">
												<!-- <div class="card__overlay"></div> -->
												<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/Cat.jpg" alt="Cat photo" /></a></div>

												<div class="card__heading">
														<span class="small">Graphic Design</span>
														<h2>Purrr-rofile</h2>
												</div>
											</div>
											<div id="card-3" class="card rounded">
												<!-- <div class="card__overlay"></div> -->
												<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/Cow.jpg" alt="Cow photo" /></a></div>

												<div class="card__heading">
														<span class="small">Graphic Design</span>
														<h2>Cow Tips</h2>
												</div>
											</div>
											<div id="card-4" class="card rounded">
												<!-- <div class="card__overlay"></div> -->
												<div class="card__image"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/img/folio/owl.jpg" alt="owl photo" /></a></div>

												<div class="card__heading">
														<span class="small">Graphic Design</span>
														<h2>Owl Graphic</h2>
												</div>
											</div>

									</section>

				</div>

			</div>
			<div class="slide">

				<div class="mirror">
					<div class="mirror__side mirror__side--one">
						<img class="display-none mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="Some image" />
					</div>
					<div class="mirror__side mirror__side--two">
						<img class="display-none mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="Some image" />
					</div>
				</div>

		<div class="overflow">
			<h1><span class="text color-text-flow">Technologies I Have Worked With </span></h1>

			<ul class="logogrid">
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/ACF.png" class="acf logogrid__img" alt="ACF"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/adobe.png" class="adobe logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/BC.png" class="bc logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/codepen.png" class="codepen logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/css3.png" class="css3 logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/github-black.png" class="github logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/heroku.png" class="heroku logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/html5.png" class="html5 logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/jquery.png" class="jquery logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/js.png" class="js logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/npm.png" class="npm logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/node.png" class="node logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/sass.png" class="sass logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/ue.png" class="ue logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/WPE.png" class="wpe logogrid__img" alt="Adobe"></li>
				<li class="logogrid__item"><img src="<?php bloginfo('stylesheet_directory');?>/img/technologies/wp-black.png" class="wp-black logogrid__img" alt="Adobe"></li>

			</ul>
		</div>


			</div>
								<div class="slide">

									<div class="mirror">
										<div class="mirror__side mirror__side--one">
											<img class="display-none mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="Some image" />
										</div>
										<div class="mirror__side mirror__side--two">
											<img class="display-none mirror__img" src="<?php bloginfo('stylesheet_directory');?>/img/5.png" alt="Some image" />
										</div>
									</div>
									<h1><span class="text color-text-flow">Contact Me Today</span></h1>
									<p>Rommel Fowler Design LLC</p>
									<p>E: info@rommelfowler.com</p>
									<p>P: 775 419 6311</p>

								</div>
			<nav class="slideshow__nav">
				<button class="btn btn--nav">Home <i class="fa fa-adjust"></i></button>
				<button class="btn btn--nav">Portfolio <i class="fa fa-adjust"></i></button>
				<button class="btn btn--nav">Technologies <i class="fa fa-adjust"></i></button>
				<button class="btn btn--nav">Contact <i class="fa fa-adjust"></i></button>

			</nav>
		</div><!-- /slideshow -->
	</section>
</main>

<?php
get_footer();
